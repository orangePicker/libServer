import { BookService } from './book.service';
import { AddBookDto } from './dto/add-book.dto';
import { FindBookDto } from './dto/find-bool.dto';
import { UpdateBookDto } from './dto/update-book.dto';
export declare class BookController {
    private readonly bookService;
    constructor(bookService: BookService);
    addBook(bookInfo: AddBookDto): Promise<{
        message: string;
        code?: undefined;
    } | {
        message: string;
        code: number;
    }>;
    querBooks(query: FindBookDto): Promise<{
        data: {
            books: any;
            total: any;
        };
    }>;
    editBook(bookInfo: UpdateBookDto): Promise<{
        message: string;
        code?: undefined;
    } | {
        message: string;
        code: number;
    }>;
    deleteBook(bookInfo: UpdateBookDto): Promise<{
        message: string;
        code: number;
    } | {
        message: string;
        code?: undefined;
    }>;
}
