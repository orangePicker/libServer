export declare class BookModule {
}
