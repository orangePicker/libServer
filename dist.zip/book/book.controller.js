"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BookController = void 0;
const common_1 = require("@nestjs/common");
const book_service_1 = require("./book.service");
const add_book_dto_1 = require("./dto/add-book.dto");
const find_bool_dto_1 = require("./dto/find-bool.dto");
const successResponse_1 = require("../interceptor/successResponse");
const update_book_dto_1 = require("./dto/update-book.dto");
let BookController = class BookController {
    constructor(bookService) {
        this.bookService = bookService;
    }
    async addBook(bookInfo) {
        try {
            const { message, success } = await this.bookService.addBook(bookInfo);
            return success ? { message } : { message, code: 0 };
        }
        catch (error) {
            throw new common_1.HttpException(error, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async querBooks(query) {
        try {
            const { data } = await this.bookService.querBooks(query);
            return {
                data: {
                    books: data,
                    total: data.length || 0,
                },
            };
        }
        catch (error) {
            throw new common_1.HttpException(error, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async editBook(bookInfo) {
        try {
            const { message, success } = await this.bookService.editBook(bookInfo);
            return success
                ? { message }
                : {
                    message,
                    code: 0,
                };
        }
        catch (error) {
            throw new Error(error);
        }
    }
    async deleteBook(bookInfo) {
        try {
            const { message, success } = await this.bookService.deleteBook(bookInfo);
            if (!success) {
                return {
                    message,
                    code: 0,
                };
            }
            return {
                message,
            };
        }
        catch (error) {
            throw new common_1.HttpException(error, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.BookController = BookController;
__decorate([
    (0, common_1.Post)('addBook'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [add_book_dto_1.AddBookDto]),
    __metadata("design:returntype", Promise)
], BookController.prototype, "addBook", null);
__decorate([
    (0, common_1.Post)('queryBooks'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [find_bool_dto_1.FindBookDto]),
    __metadata("design:returntype", Promise)
], BookController.prototype, "querBooks", null);
__decorate([
    (0, common_1.Post)('editBook'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [update_book_dto_1.UpdateBookDto]),
    __metadata("design:returntype", Promise)
], BookController.prototype, "editBook", null);
__decorate([
    (0, common_1.Post)('deleteBook'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [update_book_dto_1.UpdateBookDto]),
    __metadata("design:returntype", Promise)
], BookController.prototype, "deleteBook", null);
exports.BookController = BookController = __decorate([
    (0, common_1.Controller)('book'),
    (0, common_1.UseInterceptors)(successResponse_1.SuccessReaponse),
    __metadata("design:paramtypes", [book_service_1.BookService])
], BookController);
//# sourceMappingURL=book.controller.js.map