export declare class UpdateBookDto {
    id: number;
    bookTitle?: string;
    author?: string;
    lendState?: number;
}
