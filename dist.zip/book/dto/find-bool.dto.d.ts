export declare class FindBookDto {
    bookTitle?: string;
    author?: string;
    lendState?: number;
}
