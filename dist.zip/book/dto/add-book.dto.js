"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddBookDto = void 0;
class AddBookDto {
}
exports.AddBookDto = AddBookDto;
//# sourceMappingURL=add-book.dto.js.map