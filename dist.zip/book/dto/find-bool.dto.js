"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FindBookDto = void 0;
class FindBookDto {
}
exports.FindBookDto = FindBookDto;
//# sourceMappingURL=find-bool.dto.js.map