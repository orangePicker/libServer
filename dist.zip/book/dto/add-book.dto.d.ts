export declare class AddBookDto {
    bookTitle: string;
    author?: string;
    lendState?: number;
}
