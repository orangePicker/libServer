export declare class Book {
}
