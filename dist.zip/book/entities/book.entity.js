"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Book = void 0;
class Book {
}
exports.Book = Book;
//# sourceMappingURL=book.entity.js.map