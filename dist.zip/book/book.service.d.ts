import { AddBookDto } from './dto/add-book.dto';
import { PrismaService } from 'src/prisma/prisma.service';
import { FindBookDto } from './dto/find-bool.dto';
import { UpdateBookDto } from './dto/update-book.dto';
export declare class BookService {
    private readonly prismaDB;
    constructor(prismaDB: PrismaService);
    addBook(bookInfo: AddBookDto): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
    querBooks(query: FindBookDto): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
    editBook(bookInfo: UpdateBookDto): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
    deleteBook(bookInfo: UpdateBookDto): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
}
