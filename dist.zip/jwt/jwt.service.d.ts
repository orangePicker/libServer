import { NextFunction, Request, Response } from 'express';
import { UserDto } from 'src/user/dto/user.dto';
export declare class JwtService {
    private secret;
    constructor();
    createJWT(userInfo: UserDto): string;
    static checkJwt(req: Request, res: Response, next: NextFunction): void;
}
