export declare class JwtModule {
}
