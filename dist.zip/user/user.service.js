"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../prisma/prisma.service");
const jwt_service_1 = require("../jwt/jwt.service");
const utils_1 = require("../utils/utils");
let UserService = class UserService {
    constructor(PrimsmaDB, JwtS) {
        this.PrimsmaDB = PrimsmaDB;
        this.JwtS = JwtS;
    }
    async queryAllUser(queryUsers) {
        const filterQuery = (0, utils_1.filterObject)(queryUsers);
        const users = await this.PrimsmaDB.user.findMany({
            where: { ...filterQuery },
            select: {
                id: true,
                account: true,
                username: true,
                email: true,
                auth: true,
                status: true,
                password: false,
                book_book_userTouser: false,
            },
        });
        return (0, utils_1.serviceReturn)('查询成功', true, users);
    }
    async create(createUserDto, sessionCode, auth) {
        if (auth !== -1) {
            if (!sessionCode ||
                createUserDto.code.toLocaleLowerCase() !==
                    sessionCode.toLocaleLowerCase()) {
                return (0, utils_1.serviceReturn)('验证码错误');
            }
            if (createUserDto.password !== createUserDto.enterPassword) {
                return (0, utils_1.serviceReturn)('两次密码不一致');
            }
        }
        const checkResult = await this.PrimsmaDB.user.findMany({
            where: {
                account: createUserDto.account,
            },
        });
        if (checkResult.length >= 1) {
            return (0, utils_1.serviceReturn)('此账号已被使用');
        }
        const regResult = await this.PrimsmaDB.user.createMany({
            data: {
                account: createUserDto.account,
                password: createUserDto.password,
                auth: createUserDto.auth,
            },
        });
        if (!regResult) {
            return (0, utils_1.serviceReturn)('注册失败');
        }
        return (0, utils_1.serviceReturn)('注册成功', true);
    }
    async login(loginUserDto, sessionCode) {
        let Icode = sessionCode;
        const { account, password, code } = loginUserDto;
        if (!Icode) {
            Icode = '0';
        }
        if (Icode.toLocaleLowerCase() !== code.toLocaleLowerCase()) {
            return (0, utils_1.serviceReturn)('验证码错误');
        }
        const userInfo = await this.PrimsmaDB.user.findMany({
            where: {
                account,
                password,
            },
            select: {
                id: true,
                account: true,
                username: true,
                email: true,
                auth: true,
                status: true,
                password: false,
            },
        });
        if (userInfo.length !== 1) {
            return (0, utils_1.serviceReturn)('账号或密码错误');
        }
        const data = {
            userInfo: userInfo[0],
            token: this.JwtS.createJWT(userInfo[0]),
        };
        return (0, utils_1.serviceReturn)('登录成功', true, data);
    }
    async queryUser(userId) {
        const userInfo = await this.PrimsmaDB.user.findFirst({
            where: {
                id: userId,
            },
        });
        delete userInfo.password;
        return userInfo ? (0, utils_1.serviceReturn)('查询成功', true, userInfo) : (0, utils_1.serviceReturn)('用户不存在');
    }
    async updateUser(updateUser) {
        const filterQuery = (0, utils_1.filterObject)(updateUser);
        const result = await this.PrimsmaDB.user.update({
            where: {
                id: updateUser.id,
            },
            data: {
                ...filterQuery,
            },
        });
        return result ? (0, utils_1.serviceReturn)('修改成功', true) : (0, utils_1.serviceReturn)('修改失败');
    }
};
exports.UserService = UserService;
exports.UserService = UserService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        jwt_service_1.JwtService])
], UserService);
//# sourceMappingURL=user.service.js.map