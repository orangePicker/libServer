import { CreateUserDto } from './dto/create-user.dto';
import { LoginUserDto } from './dto/login-user.dto';
import { PrismaService } from 'src/prisma/prisma.service';
import { JwtService } from 'src/jwt/jwt.service';
import { UpdateUserDto } from './dto/update-user.dto';
import { FindUserDto } from './dto/find-user.dto';
export declare class UserService {
    private readonly PrimsmaDB;
    private readonly JwtS;
    constructor(PrimsmaDB: PrismaService, JwtS: JwtService);
    queryAllUser(queryUsers: FindUserDto): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
    create(createUserDto: CreateUserDto, sessionCode: string, auth: number): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
    login(loginUserDto: LoginUserDto, sessionCode: string): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
    queryUser(userId: number): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
    updateUser(updateUser: UpdateUserDto): Promise<{
        message: string;
        success: boolean;
        data?: any;
    }>;
}
