"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDto = void 0;
class UserDto {
}
exports.UserDto = UserDto;
//# sourceMappingURL=user.dto.js.map