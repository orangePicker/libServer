export declare class UserDto {
    id: number;
    account: string;
    username?: string;
    email?: string;
    auth: number;
}
