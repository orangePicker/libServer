"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FindUserDto = void 0;
class FindUserDto {
}
exports.FindUserDto = FindUserDto;
//# sourceMappingURL=find-user.dto.js.map