export declare class LoginUserDto {
    account: string;
    password: string;
    code: string;
}
