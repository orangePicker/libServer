export declare class FindUserDto {
    id?: number;
    account?: string;
    username?: string;
    auth?: number;
}
