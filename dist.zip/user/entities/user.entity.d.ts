export declare class User {
}
