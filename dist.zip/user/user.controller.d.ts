import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { LoginUserDto } from './dto/login-user.dto';
import { Request } from 'express';
import { UpdateUserDto } from './dto/update-user.dto';
import { FindUserDto } from './dto/find-user.dto';
export declare class UserController {
    private readonly userService;
    constructor(userService: UserService);
    create(createUserDto: CreateUserDto, session: any, req: Request): Promise<{
        message: string;
        code?: undefined;
    } | {
        message: string;
        code: number;
    }>;
    login(loginUserDto: LoginUserDto, session: any): Promise<{
        message: string;
        data: any;
    } | {
        message: string;
        data?: undefined;
    }>;
    queryUser(req: Request): Promise<{
        message: string;
        data: any;
        code?: undefined;
    } | {
        message: string;
        code: number;
        data?: undefined;
    }>;
    queryAllUser(body: FindUserDto): Promise<{
        message: string;
        data: {
            users: any;
            total: any;
        };
    }>;
    updateUser(req: Request, body: UpdateUserDto): Promise<{
        message: string;
        code?: undefined;
    } | {
        message: string;
        code: number;
    }>;
}
