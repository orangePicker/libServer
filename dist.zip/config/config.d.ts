export declare const jwtWhite: string[];
