"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jwtWhite = void 0;
exports.jwtWhite = ['/user/login', '/user/register', '/util/getCode'];
//# sourceMappingURL=config.js.map