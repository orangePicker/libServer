export declare class CaptchaModule {
}
