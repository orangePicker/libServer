import * as svgCaptcha from 'svg-captcha';
export declare class CaptchaService {
    create(): svgCaptcha.CaptchaObj;
}
