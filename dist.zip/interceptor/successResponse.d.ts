import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
interface Data<T = any> {
    code: number;
    data: T;
    message: string;
    time: number;
}
export declare class SuccessReaponse<T> implements NestInterceptor {
    private now;
    intercept(context: ExecutionContext, next: CallHandler<any>): Observable<Data<T>>;
}
export {};
