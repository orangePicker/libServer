"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@nestjs/core");
const app_module_1 = require("./app.module");
const session = require("express-session");
const cors = require("cors");
const http_exception_filter_1 = require("./exception/http-exception.filter");
const jwt_service_1 = require("./jwt/jwt.service");
const LoggerMiddleware_1 = require("./middleware/logger/LoggerMiddleware");
const dayjs = require("dayjs");
const utils_1 = require("./utils/utils");
try {
    const loggerMiddleware = new LoggerMiddleware_1.LoggerMiddleware();
    async function bootstrap() {
        const app = await core_1.NestFactory.create(app_module_1.AppModule);
        app.use(cors({
            origin: ['http://127.0.0.1:8000', 'http://localhost:8000'],
            credentials: true,
        }));
        const sessionSecret = utils_1.myEnv.SECRET_SESSION;
        app.use(session({
            secret: sessionSecret,
            name: 'org.sid',
            rolling: true,
            cookie: { maxAge: null },
            resave: true,
            saveUninitialized: false,
        }));
        app.use((req, res, next) => {
            const text = `[${dayjs().format('YYYY-MM-DD HH:mm:ss')}] ${req.method} ${req.url}\n`;
            loggerMiddleware.showLogger(text);
            next();
        });
        app.useGlobalFilters(new http_exception_filter_1.HttpExceptionFilter());
        app.use(jwt_service_1.JwtService.checkJwt);
        await app.listen(3000);
    }
    bootstrap();
}
catch (error) {
    console.error(error);
    throw new Error(error);
}
//# sourceMappingURL=main.js.map