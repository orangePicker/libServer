export declare class LoggerMiddleware {
    private logFileName;
    private errLogFileName;
    private logPath;
    private errLogPath;
    private logger;
    constructor();
    showLogger: (text: string, type?: string) => void;
    saveLogs(text: string, path: string): void;
    createLogger(): void;
    checkDir: (checkPath: string, fileName: string) => void;
}
