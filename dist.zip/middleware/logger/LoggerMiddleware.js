"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggerMiddleware = void 0;
const fs = require("node:fs");
const log4js = require("log4js");
const path = require("node:path");
const utils_1 = require("../../utils/utils");
class LoggerMiddleware {
    constructor() {
        this.logFileName = 'runtime-logger.log';
        this.errLogFileName = 'error-logger.log';
        this.logPath = path.join(__dirname, utils_1.myEnv.LOG_PATH);
        this.errLogPath = path.join(__dirname, utils_1.myEnv.LOG_PATH);
        this.logger = null;
        this.showLogger = (text, type = 'info') => {
            this.logger.level = type;
            type === 'info' ? this.logger.info(text) : this.logger.error(text);
            this.saveLogs(text, type === 'info'
                ? path.join(this.logPath, this.logFileName)
                : path.join(this.errLogPath, this.errLogFileName));
        };
        this.checkDir = (checkPath, fileName) => {
            const fullPath = path.join(checkPath, fileName);
            fs.access(fullPath, (err) => {
                if (err) {
                    console.log('文件不存在，尝试重新创建...');
                    fs.mkdir(checkPath, (err) => {
                        err
                            ? console.log('创建目录失败' + err)
                            : console.log(`${checkPath} 已创建!`);
                    });
                    fs.appendFile(fullPath, '', 'utf-8', (err) => {
                        err
                            ? console.log('文件重新创建失败!')
                            : console.log('文件重新创建成功!' + fullPath);
                    });
                }
                else {
                    console.log(`文件 ${fullPath} 存在!`);
                }
            });
        };
        this.checkDir(this.logPath, this.logFileName);
        this.checkDir(this.errLogPath, this.errLogFileName);
        this.createLogger();
    }
    saveLogs(text, path) {
        fs.writeFileSync(path, text, {
            encoding: 'utf-8',
            flag: 'a',
        });
    }
    createLogger() {
        this.logger = log4js.getLogger();
    }
}
exports.LoggerMiddleware = LoggerMiddleware;
//# sourceMappingURL=LoggerMiddleware.js.map