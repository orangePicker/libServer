"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateUtilDto = void 0;
class CreateUtilDto {
}
exports.CreateUtilDto = CreateUtilDto;
//# sourceMappingURL=create-util.dto.js.map