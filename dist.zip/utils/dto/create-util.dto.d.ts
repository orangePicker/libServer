export declare class CreateUtilDto {
}
