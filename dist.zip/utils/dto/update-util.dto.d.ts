import { CreateUtilDto } from './create-util.dto';
declare const UpdateUtilDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateUtilDto>>;
export declare class UpdateUtilDto extends UpdateUtilDto_base {
}
export {};
