import { CaptchaService } from 'src/captcha/captcha.service';
export declare class UtilsService {
    private readonly captchaService;
    constructor(captchaService: CaptchaService);
    createCaptcha(): import("svg-captcha").CaptchaObj;
}
