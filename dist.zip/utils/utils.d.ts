export declare const objToString: (obj: object) => string;
export declare const filterObject: (obj: object) => {};
export declare const serviceReturn: (message?: string, success?: boolean, data?: any) => {
    message: string;
    success: boolean;
    data?: any;
};
export declare const myEnv: import("dotenv").DotenvParseOutput;
