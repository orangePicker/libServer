"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.myEnv = exports.serviceReturn = exports.filterObject = exports.objToString = void 0;
const dotenv_1 = require("dotenv");
const objToString = (obj) => JSON.stringify(obj);
exports.objToString = objToString;
const filterObject = (obj) => {
    const data = {};
    const keys = Object.keys(obj);
    keys.forEach((key) => {
        if (obj[key] || obj[key] === 0) {
            data[key] = obj[key];
        }
    });
    return data;
};
exports.filterObject = filterObject;
const serviceReturn = (message = '', success = false, data) => {
    return {
        message,
        success,
        data,
    };
};
exports.serviceReturn = serviceReturn;
exports.myEnv = (0, dotenv_1.config)().parsed;
//# sourceMappingURL=utils.js.map