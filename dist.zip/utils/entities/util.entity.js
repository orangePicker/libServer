"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Util = void 0;
class Util {
}
exports.Util = Util;
//# sourceMappingURL=util.entity.js.map