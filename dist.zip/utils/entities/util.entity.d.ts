export declare class Util {
}
