import { UtilsService } from './utils.service';
export declare class UtilsController {
    private readonly utilsService;
    constructor(utilsService: UtilsService);
    createCaptcha(session: any): string;
}
