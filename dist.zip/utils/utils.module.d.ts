export declare class UtilsModule {
}
